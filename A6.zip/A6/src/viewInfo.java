public class viewInfo {
    public double x;
    public double y;
    public double speed;
    public double dir;
}